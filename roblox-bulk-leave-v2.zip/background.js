// Clicking the toolbar icon opens the panel on the current Roblox tab.
// If the tab isn't a Roblox page (or hasn't loaded the content script), open Roblox communities instead.
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "rbl-toggle" });
  } catch (e) {
    chrome.tabs.create({ url: "https://www.roblox.com/communities" });
  }
});
