(() => {
  if (window.__rblxBulkLeave) return;
  window.__rblxBulkLeave = true;

  /* ───────────────────────── API layer ───────────────────────── */

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let csrf = null;

  async function api(url, opts = {}, retries = 4) {
    const headers = { ...(opts.headers || {}) };
    const sentToken = csrf;
    if (sentToken) headers["x-csrf-token"] = sentToken;

    let res;
    try {
      res = await fetch(url, { ...opts, headers, credentials: "include" });
    } catch (e) {
      if (retries > 0) {
        await sleep(1500);
        return api(url, opts, retries - 1);
      }
      throw e;
    }

    const token = res.headers.get("x-csrf-token");
    if (token) csrf = token;

    // Roblox hands out a fresh CSRF token on the first rejected write.
    if (res.status === 403 && token && token !== sentToken && retries > 0) {
      return api(url, opts, retries - 1);
    }
    if (res.status === 429 && retries > 0) {
      const wait = Math.min(Number(res.headers.get("retry-after")) || 5, 30);
      await sleep(wait * 1000);
      return api(url, opts, retries - 1);
    }
    return res;
  }

  async function getUserId() {
    const res = await api("https://users.roblox.com/v1/users/authenticated");
    if (!res.ok) throw new Error("You need to be logged in to Roblox.");
    return (await res.json()).id;
  }

  async function getGroups(userId) {
    const res = await api(
      `https://groups.roblox.com/v2/users/${userId}/groups/roles?includeLocked=true`
    );
    if (!res.ok) throw new Error(`Couldn't load your communities (${res.status}).`);
    const json = await res.json();
    return json.data.map((d) => ({
      id: d.group.id,
      name: d.group.name,
      members: d.group.memberCount || 0,
      role: d.role.name,
      isOwner: d.role.rank === 255,
      thumb: null,
      selected: false,
      status: "idle", // idle | busy | ok | fail
      error: "",
    }));
  }

  async function getThumbs(ids) {
    const out = {};
    for (let i = 0; i < ids.length; i += 100) {
      const chunk = ids.slice(i, i + 100);
      try {
        const res = await api(
          `https://thumbnails.roblox.com/v1/groups/icons?groupIds=${chunk.join(",")}&size=150x150&format=Png&isCircular=false`
        );
        if (res.ok) {
          (await res.json()).data.forEach((d) => {
            if (d.imageUrl) out[d.targetId] = d.imageUrl;
          });
        }
      } catch (_) {}
    }
    return out;
  }

  async function leaveGroup(groupId, userId) {
    try {
      const res = await api(
        `https://groups.roblox.com/v1/groups/${groupId}/users/${userId}`,
        { method: "DELETE" }
      );
      if (res.ok) return { ok: true };
      let msg = `Failed (${res.status})`;
      try {
        const j = await res.json();
        if (j.errors && j.errors[0] && j.errors[0].message) msg = j.errors[0].message;
      } catch (_) {}
      return { ok: false, msg };
    } catch (e) {
      return { ok: false, msg: "Network error" };
    }
  }

  /* ───────────────────────── Styles ───────────────────────── */

  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .root {
    --bg: #1a1c1f; --panel: #212428; --panel2: #292d31; --line: #33383d;
    --text: #eef0f2; --muted: #8e979f; --accent: #3d7bff; --danger: #f0443a;
    --ok: #34c77b; --warn: #f5a524;
    font: 14px/1.4 -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: var(--text);
  }

  /* floating launcher */
  .fab {
    position: fixed; right: 20px; bottom: 20px; z-index: 2147483000;
    width: 48px; height: 48px; border-radius: 50%; border: 0; cursor: pointer; padding: 0;
    background: linear-gradient(135deg, #ff5a4d, #c4241b); color: #fff;
    display: grid; place-items: center;
    box-shadow: 0 6px 18px rgba(0,0,0,.45), inset 0 1px 0 rgba(255,255,255,.25);
    transition: transform .18s ease, box-shadow .18s ease;
    animation: pop .4s cubic-bezier(.2,1.4,.4,1) both .6s;
  }
  .fab:hover { transform: scale(1.08) rotate(-4deg); box-shadow: 0 8px 22px rgba(0,0,0,.55); }
  .fab:active { transform: scale(.95); }
  .fab svg { width: 24px; height: 24px; }

  /* modal */
  .backdrop {
    position: fixed; inset: 0; z-index: 2147483001; display: none;
    align-items: center; justify-content: center; padding: 16px;
    background: rgba(8,9,11,.62); backdrop-filter: blur(3px);
  }
  .backdrop.open { display: flex; animation: fade .18s ease both; }
  .modal {
    position: relative; width: min(560px, 100%); max-height: min(720px, 92vh);
    display: flex; flex-direction: column; overflow: hidden;
    background: var(--bg); border: 1px solid var(--line); border-radius: 16px;
    box-shadow: 0 24px 70px rgba(0,0,0,.6);
    animation: rise .26s cubic-bezier(.2,.9,.3,1) both;
  }

  header { padding: 18px 20px 12px; display: flex; align-items: center; gap: 12px; }
  .logo { width: 36px; height: 36px; flex: none; border-radius: 10px; display: grid; place-items: center;
    background: linear-gradient(135deg, #ff5a4d, #c4241b); }
  .logo svg { width: 20px; height: 20px; color: #fff; }
  .titles { flex: 1; min-width: 0; }
  .title { font-weight: 700; font-size: 16px; letter-spacing: .1px; }
  .sub { color: var(--muted); font-size: 12px; margin-top: 1px; }
  .x { width: 32px; height: 32px; border: 0; border-radius: 8px; background: transparent; color: var(--muted);
    cursor: pointer; font-size: 20px; line-height: 1; transition: background .15s, color .15s; }
  .x:hover { background: var(--panel2); color: var(--text); }

  .toolbar { padding: 0 20px 12px; display: flex; flex-direction: column; gap: 10px; }
  .searchwrap { position: relative; }
  .searchwrap svg { position: absolute; left: 11px; top: 50%; width: 16px; height: 16px; transform: translateY(-50%); color: var(--muted); }
  .search {
    width: 100%; height: 38px; padding: 0 12px 0 34px; border-radius: 10px; outline: none;
    border: 1px solid var(--line); background: var(--panel); color: var(--text); font: inherit;
    transition: border-color .15s, box-shadow .15s;
  }
  .search:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(61,123,255,.22); }
  .search::placeholder { color: var(--muted); }

  .controls { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .seg { display: inline-flex; background: var(--panel); border: 1px solid var(--line); border-radius: 9px; padding: 2px; }
  .seg button { border: 0; background: transparent; color: var(--muted); padding: 5px 11px; border-radius: 7px;
    font: inherit; font-size: 12px; font-weight: 600; cursor: pointer; transition: background .15s, color .15s; }
  .seg button.on { background: var(--panel2); color: var(--text); }
  select.sort {
    height: 30px; border-radius: 9px; border: 1px solid var(--line); background: var(--panel); color: var(--text);
    font: inherit; font-size: 12px; padding: 0 8px; outline: none; cursor: pointer;
  }
  .spacer { flex: 1; }
  .link { border: 0; background: none; color: var(--accent); font: inherit; font-size: 12px; font-weight: 600;
    cursor: pointer; padding: 4px 6px; border-radius: 6px; }
  .link:hover { background: rgba(61,123,255,.12); }
  .link:disabled { opacity: .4; cursor: not-allowed; background: none; }

  /* list */
  .list { flex: 1; overflow-y: auto; padding: 4px 12px 8px; border-top: 1px solid var(--line); min-height: 160px;
    scrollbar-width: thin; scrollbar-color: #3a4046 transparent; }
  .list::-webkit-scrollbar { width: 8px; }
  .list::-webkit-scrollbar-thumb { background: #3a4046; border-radius: 8px; }
  .row {
    display: flex; align-items: center; gap: 12px; padding: 8px 8px; margin: 2px 0; border-radius: 10px;
    cursor: pointer; user-select: none; outline: none; border: 1px solid transparent;
    transition: background .12s, border-color .12s, opacity .3s, transform .3s;
  }
  .row:hover { background: var(--panel); }
  .row:focus-visible { border-color: var(--accent); }
  .row.sel { background: rgba(61,123,255,.1); border-color: rgba(61,123,255,.35); }
  .row.locked { opacity: .45; cursor: not-allowed; }
  .row.locked:hover { background: transparent; }
  .row.leaving { opacity: 0; transform: translateX(24px); }
  .row.busy { background: var(--panel); border-color: var(--line); }
  .row.fail { border-color: rgba(240,68,58,.45); background: rgba(240,68,58,.07); }

  .check { width: 20px; height: 20px; flex: none; border-radius: 6px; border: 2px solid #4a5159; display: grid; place-items: center;
    transition: background .15s, border-color .15s, transform .15s; }
  .check svg { width: 12px; height: 12px; color: #fff; opacity: 0; transform: scale(.4); transition: opacity .15s, transform .18s cubic-bezier(.2,1.6,.4,1); }
  .row.sel .check { background: var(--accent); border-color: var(--accent); }
  .row.sel .check svg { opacity: 1; transform: scale(1); }
  .row.locked .check { visibility: hidden; }

  .av { width: 40px; height: 40px; flex: none; border-radius: 10px; background: var(--panel2); overflow: hidden;
    display: grid; place-items: center; color: var(--muted); font-weight: 700; font-size: 15px; position: relative; }
  .av img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; opacity: 0; transition: opacity .3s; }
  .av img.in { opacity: 1; }

  .meta { flex: 1; min-width: 0; }
  .name { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .info { color: var(--muted); font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .info.err { color: #ff8b83; white-space: normal; }

  .badge { flex: none; font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 99px; background: var(--panel2); color: var(--muted); }
  .badge.owner { background: rgba(245,165,36,.15); color: var(--warn); }
  .state { flex: none; width: 22px; height: 22px; display: grid; place-items: center; }
  .spin { width: 18px; height: 18px; border-radius: 50%; border: 2.5px solid #3a4046; border-top-color: var(--accent); animation: spin .7s linear infinite; }
  .okmark { color: var(--ok); width: 20px; height: 20px; }
  .failmark { color: var(--danger); width: 20px; height: 20px; }

  .empty { text-align: center; color: var(--muted); padding: 48px 16px; }
  .skeleton { display: flex; align-items: center; gap: 12px; padding: 10px 8px; }
  .skeleton i { display: block; border-radius: 8px; background: linear-gradient(90deg, var(--panel) 25%, var(--panel2) 50%, var(--panel) 75%); background-size: 200% 100%; animation: shimmer 1.2s infinite; }

  /* footer */
  footer { border-top: 1px solid var(--line); padding: 14px 20px 16px; background: var(--panel); display: flex; flex-direction: column; gap: 10px; }
  .progress { height: 6px; background: var(--panel2); border-radius: 99px; overflow: hidden; display: none; }
  .progress.show { display: block; }
  .bar { height: 100%; width: 0%; background: linear-gradient(90deg, var(--accent), #6aa0ff); border-radius: 99px; transition: width .35s ease; }
  .foot { display: flex; align-items: center; gap: 10px; }
  .status { flex: 1; min-width: 0; color: var(--muted); font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .status b { color: var(--text); }
  .btn { border: 0; border-radius: 10px; height: 38px; padding: 0 18px; font: inherit; font-weight: 700; cursor: pointer; color: #fff;
    background: var(--accent); transition: filter .15s, transform .1s, opacity .15s; }
  .btn:hover { filter: brightness(1.1); }
  .btn:active { transform: scale(.97); }
  .btn.danger { background: var(--danger); }
  .btn.ghost { background: var(--panel2); color: var(--text); }
  .btn:disabled { opacity: .4; cursor: not-allowed; filter: none; transform: none; }

  /* confirm */
  .confirm { position: absolute; inset: 0; display: none; align-items: center; justify-content: center; padding: 24px;
    background: rgba(10,11,13,.72); backdrop-filter: blur(4px); z-index: 5; }
  .confirm.open { display: flex; animation: fade .15s ease both; }
  .card { background: var(--bg); border: 1px solid var(--line); border-radius: 14px; padding: 22px; width: min(360px, 100%);
    text-align: center; animation: rise .22s cubic-bezier(.2,1.2,.4,1) both; }
  .card .big { width: 48px; height: 48px; margin: 0 auto 12px; border-radius: 50%; display: grid; place-items: center;
    background: rgba(240,68,58,.15); color: var(--danger); }
  .card .big svg { width: 24px; height: 24px; }
  .card h3 { margin: 0 0 6px; font-size: 17px; }
  .card p { margin: 0 0 18px; color: var(--muted); font-size: 13px; }
  .card .btns { display: flex; gap: 10px; }
  .card .btns .btn { flex: 1; }

  /* toast */
  .toast { position: absolute; left: 50%; bottom: 84px; transform: translate(-50%, 12px); background: #101214; color: var(--text);
    border: 1px solid var(--line); padding: 8px 14px; border-radius: 99px; font-size: 13px; opacity: 0; pointer-events: none;
    transition: opacity .2s, transform .2s; z-index: 6; white-space: nowrap; }
  .toast.show { opacity: 1; transform: translate(-50%, 0); }

  @keyframes fade { from { opacity: 0 } to { opacity: 1 } }
  @keyframes rise { from { opacity: 0; transform: translateY(14px) scale(.97) } to { opacity: 1; transform: none } }
  @keyframes pop { from { opacity: 0; transform: scale(.4) } to { opacity: 1; transform: none } }
  @keyframes spin { to { transform: rotate(360deg) } }
  @keyframes shimmer { to { background-position: -200% 0 } }
  @media (prefers-reduced-motion: reduce) { * { animation-duration: .01ms !important; transition-duration: .01ms !important; } }
  @media (max-width: 480px) { .modal { max-height: 96vh; border-radius: 14px; } }
  `;

  /* ───────────────────────── Markup ───────────────────────── */

  const ICON_EXIT = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><path d="M15 8l4 4-4 4"/><path d="M19 12H9"/></svg>`;
  const ICON_CHECK = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>`;
  const ICON_OK = `<svg class="okmark" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.8"/></svg>`;
  const ICON_FAIL = `<svg class="failmark" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg>`;
  const ICON_SEARCH = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>`;
  const ICON_WARN = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18.5v.01"/></svg>`;

  const host = document.createElement("div");
  host.id = "rbl-host";
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>${CSS}</style>
    <div class="root">
      <button class="fab" title="Leave multiple communities" aria-label="Leave multiple communities">${ICON_EXIT}</button>
      <div class="backdrop">
        <div class="modal" role="dialog" aria-modal="true" aria-label="Leave multiple communities">
          <header>
            <div class="logo">${ICON_EXIT}</div>
            <div class="titles">
              <div class="title">Leave communities</div>
              <div class="sub" data-sub>Loading…</div>
            </div>
            <button class="x" data-close aria-label="Close">×</button>
          </header>
          <div class="toolbar">
            <div class="searchwrap">${ICON_SEARCH}<input class="search" data-search placeholder="Search your communities…" autocomplete="off" spellcheck="false"></div>
            <div class="controls">
              <div class="seg"><button data-filter="all" class="on">All</button><button data-filter="selected">Selected</button></div>
              <select class="sort" data-sort aria-label="Sort">
                <option value="name">A → Z</option>
                <option value="members-desc">Most members</option>
                <option value="members-asc">Fewest members</option>
              </select>
              <span class="spacer"></span>
              <button class="link" data-all>Select all</button>
              <button class="link" data-none>Clear</button>
            </div>
          </div>
          <div class="list" data-list></div>
          <footer>
            <div class="progress" data-progress><div class="bar" data-bar></div></div>
            <div class="foot">
              <div class="status" data-status></div>
              <button class="btn ghost" data-stop style="display:none">Stop</button>
              <button class="btn danger" data-go disabled>Leave</button>
            </div>
          </footer>
          <div class="toast" data-toast></div>
          <div class="confirm" data-confirm>
            <div class="card">
              <div class="big">${ICON_WARN}</div>
              <h3 data-ctitle>Leave communities?</h3>
              <p>You'll lose your rank and access in each one. You'd have to rejoin manually.</p>
              <div class="btns">
                <button class="btn ghost" data-cancel>Cancel</button>
                <button class="btn danger" data-confirm-go>Yes, leave</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  const $ = (s) => shadow.querySelector(s);
  const el = {
    fab: $(".fab"), backdrop: $(".backdrop"), sub: $("[data-sub]"), list: $("[data-list]"),
    search: $("[data-search]"), sort: $("[data-sort]"), go: $("[data-go]"), stop: $("[data-stop]"),
    status: $("[data-status]"), progress: $("[data-progress]"), bar: $("[data-bar]"),
    confirm: $("[data-confirm]"), ctitle: $("[data-ctitle]"), toast: $("[data-toast]"),
    all: $("[data-all]"), none: $("[data-none]"),
  };

  /* ───────────────────────── State & rendering ───────────────────────── */

  let groups = [];
  let userId = null;
  let filter = "all";
  let running = false;
  let cancelled = false;
  let lastClickedId = null;
  let rows = new Map(); // id -> element
  let toastTimer;

  const fmt = (n) => n.toLocaleString();
  const isOpen = () => el.backdrop.classList.contains("open");

  function toast(msg) {
    el.toast.textContent = msg;
    el.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.remove("show"), 2600);
  }

  function visibleGroups() {
    const q = el.search.value.trim().toLowerCase();
    let list = groups.filter((g) => (!q || g.name.toLowerCase().includes(q)) && (filter === "all" || g.selected));
    const s = el.sort.value;
    list = list.slice().sort((a, b) =>
      s === "members-desc" ? b.members - a.members :
      s === "members-asc" ? a.members - b.members :
      a.name.localeCompare(b.name)
    );
    return list;
  }

  function selectedGroups() {
    return groups.filter((g) => g.selected && !g.isOwner);
  }

  function updateChrome() {
    const sel = selectedGroups().length;
    el.sub.textContent = groups.length
      ? `${fmt(groups.length)} communit${groups.length === 1 ? "y" : "ies"} · ${fmt(sel)} selected`
      : "No communities";
    if (!running) {
      el.go.disabled = sel === 0;
      el.go.textContent = sel ? `Leave ${fmt(sel)}` : "Leave";
      el.status.innerHTML = sel
        ? `<b>${fmt(sel)}</b> selected`
        : "Pick the communities you want to leave";
    }
    const canEdit = !running;
    el.all.disabled = !canEdit; el.none.disabled = !canEdit;
  }

  function setRowState(g) {
    const row = rows.get(g.id);
    if (!row) return;
    row.classList.toggle("sel", g.selected && !g.isOwner);
    row.classList.toggle("busy", g.status === "busy");
    row.classList.toggle("fail", g.status === "fail");
    row.setAttribute("aria-checked", String(g.selected));
    const state = row.querySelector(".state");
    const info = row.querySelector(".info");
    state.innerHTML =
      g.status === "busy" ? `<div class="spin"></div>` :
      g.status === "ok" ? ICON_OK :
      g.status === "fail" ? ICON_FAIL : "";
    if (g.status === "fail") { info.textContent = g.error || "Couldn't leave"; info.classList.add("err"); }
    else if (g.status === "busy") { info.textContent = "Leaving…"; info.classList.remove("err"); }
    else if (g.status === "ok") { info.textContent = "Left"; info.classList.remove("err"); }
    else { info.textContent = infoText(g); info.classList.remove("err"); }
  }

  const infoText = (g) => `${fmt(g.members)} member${g.members === 1 ? "" : "s"} · ${g.role}`;

  function buildRow(g) {
    const row = document.createElement("div");
    row.className = "row" + (g.isOwner ? " locked" : "");
    row.tabIndex = 0;
    row.setAttribute("role", "checkbox");
    row.dataset.id = g.id;
    row.innerHTML = `
      <div class="check">${ICON_CHECK}</div>
      <div class="av"><span></span><img alt="" draggable="false"></div>
      <div class="meta"><div class="name"></div><div class="info"></div></div>
      ${g.isOwner ? `<span class="badge owner">Owner</span>` : ""}
      <div class="state"></div>`;
    row.querySelector(".name").textContent = g.name;
    row.querySelector(".name").title = g.name;
    row.querySelector(".av span").textContent = (g.name.trim()[0] || "?").toUpperCase();
    attachThumb(row, g);
    rows.set(g.id, row);
    setRowState(g);
    return row;
  }

  function attachThumb(row, g) {
    if (!g.thumb) return;
    const img = row.querySelector(".av img");
    img.onload = () => img.classList.add("in");
    img.src = g.thumb;
  }

  function render() {
    rows = new Map();
    el.list.textContent = "";
    const list = visibleGroups();
    if (!list.length) {
      const d = document.createElement("div");
      d.className = "empty";
      d.textContent = groups.length
        ? (filter === "selected" ? "Nothing selected yet." : "No communities match your search.")
        : "You're not in any communities.";
      el.list.appendChild(d);
    } else {
      const frag = document.createDocumentFragment();
      list.forEach((g) => frag.appendChild(buildRow(g)));
      el.list.appendChild(frag);
    }
    updateChrome();
  }

  function showSkeleton() {
    el.list.textContent = "";
    for (let i = 0; i < 6; i++) {
      const s = document.createElement("div");
      s.className = "skeleton";
      s.innerHTML = `<i style="width:20px;height:20px"></i><i style="width:40px;height:40px"></i><div style="flex:1;display:flex;flex-direction:column;gap:6px"><i style="height:12px;width:${50 + ((i * 17) % 35)}%"></i><i style="height:10px;width:30%"></i></div>`;
      el.list.appendChild(s);
    }
  }

  /* ───────────────────────── Interaction ───────────────────────── */

  function toggleGroup(g, value) {
    if (g.isOwner || running) return;
    g.selected = value === undefined ? !g.selected : value;
    setRowState(g);
  }

  function handleRowActivate(row, e) {
    const g = groups.find((x) => String(x.id) === row.dataset.id);
    if (!g || g.isOwner || running) return;

    if (e && e.shiftKey && lastClickedId != null) {
      const order = visibleGroups().filter((x) => !x.isOwner);
      const a = order.findIndex((x) => x.id === lastClickedId);
      const b = order.findIndex((x) => x.id === g.id);
      if (a !== -1 && b !== -1) {
        const [lo, hi] = a < b ? [a, b] : [b, a];
        const val = !g.selected;
        for (let i = lo; i <= hi; i++) toggleGroup(order[i], val);
        updateChrome();
        return;
      }
    }
    toggleGroup(g);
    lastClickedId = g.id;
    if (filter === "selected" && !g.selected) render(); else updateChrome();
  }

  el.list.addEventListener("click", (e) => {
    const row = e.target.closest(".row");
    if (row) handleRowActivate(row, e);
  });
  el.list.addEventListener("keydown", (e) => {
    const row = e.target.closest(".row");
    if (!row) return;
    if (e.key === " " || e.key === "Enter") { e.preventDefault(); handleRowActivate(row, e); }
    else if (e.key === "ArrowDown" && row.nextElementSibling) { e.preventDefault(); row.nextElementSibling.focus(); }
    else if (e.key === "ArrowUp" && row.previousElementSibling) { e.preventDefault(); row.previousElementSibling.focus(); }
  });

  el.search.addEventListener("input", render);
  el.sort.addEventListener("change", render);
  shadow.querySelectorAll("[data-filter]").forEach((b) =>
    b.addEventListener("click", () => {
      filter = b.dataset.filter;
      shadow.querySelectorAll("[data-filter]").forEach((x) => x.classList.toggle("on", x === b));
      render();
    })
  );
  el.all.addEventListener("click", () => {
    visibleGroups().forEach((g) => toggleGroup(g, true));
    updateChrome();
  });
  el.none.addEventListener("click", () => {
    groups.forEach((g) => (g.selected = false));
    render();
  });

  // confirm flow
  el.go.addEventListener("click", () => {
    const n = selectedGroups().length;
    if (!n) return;
    el.ctitle.textContent = `Leave ${fmt(n)} communit${n === 1 ? "y" : "ies"}?`;
    el.confirm.classList.add("open");
    shadow.querySelector("[data-confirm-go]").focus();
  });
  shadow.querySelector("[data-cancel]").addEventListener("click", () => el.confirm.classList.remove("open"));
  shadow.querySelector("[data-confirm-go]").addEventListener("click", () => {
    el.confirm.classList.remove("open");
    runLeave();
  });
  el.stop.addEventListener("click", () => {
    cancelled = true;
    el.stop.disabled = true;
    el.status.textContent = "Stopping after the current one…";
  });

  /* ───────────────────────── Leaving ───────────────────────── */

  async function runLeave() {
    const targets = selectedGroups();
    if (!targets.length) return;

    running = true;
    cancelled = false;
    el.go.disabled = true;
    el.stop.style.display = "";
    el.stop.disabled = false;
    el.progress.classList.add("show");
    el.bar.style.width = "0%";
    el.search.disabled = true;
    el.sort.disabled = true;
    updateChrome();

    targets.forEach((g) => { g.status = "idle"; g.error = ""; setRowState(g); });

    let ok = 0, fail = 0, done = 0;
    for (const g of targets) {
      if (cancelled) break;
      g.status = "busy";
      setRowState(g);
      const row = rows.get(g.id);
      if (row) row.scrollIntoView({ block: "nearest", behavior: "smooth" });
      el.status.innerHTML = `Leaving <b>${fmt(done + 1)}</b> of <b>${fmt(targets.length)}</b> · ${escapeHtml(g.name)}`;

      const r = await leaveGroup(g.id, userId);
      done++;
      if (r.ok) { g.status = "ok"; g.selected = false; ok++; }
      else { g.status = "fail"; g.error = r.msg; fail++; }
      setRowState(g);
      el.bar.style.width = `${Math.round((done / targets.length) * 100)}%`;

      if (done < targets.length && !cancelled) await sleep(800 + Math.random() * 500);
    }

    // Animate out the ones we left, then drop them from the list.
    const left = groups.filter((g) => g.status === "ok");
    left.forEach((g) => { const r = rows.get(g.id); if (r) r.classList.add("leaving"); });
    await sleep(left.length ? 380 : 0);
    groups = groups.filter((g) => g.status !== "ok");

    running = false;
    el.stop.style.display = "none";
    el.search.disabled = false;
    el.sort.disabled = false;
    setTimeout(() => el.progress.classList.remove("show"), 900);
    render();

    const parts = [];
    if (ok) parts.push(`Left ${fmt(ok)}`);
    if (fail) parts.push(`${fmt(fail)} failed`);
    if (cancelled) parts.push("stopped early");
    toast(parts.join(" · ") || "Nothing to do");
    el.status.innerHTML = fail
      ? `<b>${fmt(ok)}</b> left · <b>${fmt(fail)}</b> couldn't be left (hover the red rows)`
      : (selectedGroups().length ? `<b>${fmt(selectedGroups().length)}</b> selected` : ok ? `Done — left <b>${fmt(ok)}</b>` : el.status.innerHTML);
  }

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  /* ───────────────────────── Open / close ───────────────────────── */

  async function load() {
    showSkeleton();
    el.sub.textContent = "Loading…";
    el.go.disabled = true;
    try {
      userId = userId || (await getUserId());
      const fresh = await getGroups(userId);
      const prevSel = new Set(groups.filter((g) => g.selected).map((g) => g.id));
      fresh.forEach((g) => (g.selected = prevSel.has(g.id) && !g.isOwner));
      groups = fresh;
      render();
      getThumbs(groups.map((g) => g.id)).then((map) => {
        groups.forEach((g) => {
          if (map[g.id]) {
            g.thumb = map[g.id];
            const row = rows.get(g.id);
            if (row) attachThumb(row, g);
          }
        });
      });
    } catch (e) {
      el.list.textContent = "";
      const d = document.createElement("div");
      d.className = "empty";
      d.textContent = e.message || "Something went wrong.";
      el.list.appendChild(d);
      el.sub.textContent = "Error";
    }
  }

  function open() {
    if (isOpen()) return;
    el.backdrop.classList.add("open");
    load();
    setTimeout(() => el.search.focus(), 60);
  }
  function close() {
    if (running) { toast("Hang on — still leaving communities"); return; }
    el.confirm.classList.remove("open");
    el.backdrop.classList.remove("open");
  }
  function toggle() { isOpen() ? close() : open(); }

  el.fab.addEventListener("click", open);
  shadow.querySelector("[data-close]").addEventListener("click", close);
  el.backdrop.addEventListener("mousedown", (e) => { if (e.target === el.backdrop) close(); });
  window.addEventListener("keydown", (e) => {
    if (!isOpen()) return;
    if (e.key === "Escape") {
      e.stopPropagation();
      if (el.confirm.classList.contains("open")) el.confirm.classList.remove("open"); else close();
    }
  }, true);

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "rbl-toggle") toggle();
    });
  } catch (_) {}

  document.documentElement.appendChild(host);
})();
